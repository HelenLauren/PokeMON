package com.pokemon.main;

import javax.swing.*;
import java.awt.*;

public class GameOver {
    public static void main(String[] args) {
        // Cria o JDialog em vez do JOptionPane
        JDialog dialog = new JDialog();
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setSize(800, 450); // Aumenta o tamanho da janela
        dialog.setLocationRelativeTo(null); // Centraliza a janela na tela

        // Carrega a imagem para ser usada como fundo
        ImageIcon backgroundImage = new ImageIcon("src/com/pokemon/main/gameover.jpg");

        // Verifica se a imagem foi carregada corretamente
        if (backgroundImage.getImageLoadStatus() != MediaTracker.COMPLETE) {
            System.out.println("Erro ao carregar a imagem!");
        }

        // Cria um painel customizado para usar a imagem de fundo
        JPanel panelFundo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);  // Chama o método da superclasse
                // Desenha a imagem de fundo ajustada ao tamanho do painel
                g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };
        panelFundo.setLayout(new BorderLayout());

        // Adiciona um JLabel com a mensagem desejada
        JLabel label = new JLabel("GAME OVER: Todos seus pokemons estão esgotados", JLabel.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setForeground(Color.WHITE);  // Garante que o texto tenha cor visível
        panelFundo.add(label, BorderLayout.CENTER);

        // Adiciona o painel com a imagem de fundo ao JDialog
        dialog.add(panelFundo);

        // Exibe a janela de diálogo
        dialog.setVisible(true);
    }
}
