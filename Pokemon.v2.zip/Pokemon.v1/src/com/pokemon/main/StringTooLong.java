package com.pokemon.main;

public class StringTooLong extends Exception{
    StringTooLong(String msg) {

        super(msg);
    }
}